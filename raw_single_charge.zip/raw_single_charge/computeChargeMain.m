function particle = computeChargeMain

    close all;

    tic
    
    % Number of Monte Carlo simulations
    data.N_Montecarlo = 10000;
    
    % Number of charges
    data.N_Qs = 500;
    data.N_Qsingle = 10000;
    
    data = defineGlobalData(data);
    
    particle = masterFunction(data);
    toc
end


% /////////////////////////////////////////////////////////////////////////
% ////////////////////// SECONDARY FUNCTIONS //////////////////////////////
% /////////////////////////////////////////////////////////////////////////




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% GLOBAL CONSTANTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function data = defineGlobalData(data)

    data.dt_s = 1/1500;                                                    % Delta time of acquisition (1/fps) [s]
    data.N_points_fit = 1000;                                              % Points used to fit the trajectory and the velocity
    data.N_hist_1 = 10;                                                    % Number of bins used for the histogram of the areas
    data.rho_air = 1.16;                                                   % Air density measured on the ground
    data.g = 9.81;                                                         % Gravitational acceleration
    data.mu_kyn_air = 1.8e-5;                                              % Kynematic viscosity of the air
    data.vis_dyn = 18.37e-6;                                               % Dinamic viscosity of the air
    data.rho_min = 50;                                                     % Minimum density allowed
    data.rho_max = 3500;                                                   % Maximum density allowed
    data.E0 = 572*1e3;                  			    				   % Electric field in V/m
    data.E0_sigma = 113*1e3;                                               % Electric field sigma in V/m
    data.MaxQDensity = 100*1e-6;                                           % Old default 27*1e-6;
    
%     data.fileIdVector = [2];                                              % TXT file ID vector
%     data.id4TerminalVelocity = [7];                                       % Number of frames beyond those the electric field is on     
                               
    
    data.fileIdVector = [2 3 4 5 6 7 8 9 ...
                         10 11 12 13 14 15 16 17 18 19 ...
                         20 21 22 23 25 26 27 29 ...
                         30 31 32 33 38 40 41 43 44 45 ...
                         46 48 50 51 56 57 58 59];                         % TXT file ID vector
                   
    data.id4TerminalVelocity = [7 9 9 10 8 9 9 17 ...
                                10 35 12 9 10 35 20 12 9 10 ...
                                10 25 15 22 99 12 13 15 ...
                                15 10 11 15 13 16 20 18 21 23 ...
                                18 13 13 17 19 21 45 23];                  % Number of frames beyond those the electric field is on     
               
                   
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% TREATMENT OF THE RAW DATA %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function particle = createNewParticle(id_p, data, particle)

    % Creating the string variable
    filename = sprintf('data_%d.txt', id_p);                               % Single filename

    % Reading the single .txt file
    table_raw = readSingleTxt(filename);                                   % Matrix with raw data for a single particle
     
    last_frame_tv = data.id4TerminalVelocity(find(data.fileIdVector==id_p)); % Terminal velocity last frame
    
    % Creating particle structure
    particle(id_p).all_area_mm2 = table_raw(:,2);                          % Particle raw area vector [mm^2]
    particle(id_p).max_all_area_mm2 = max(particle(id_p).all_area_mm2);    % Particle max area [mm^2]
    particle(id_p).min_all_area_mm2 = min(particle(id_p).all_area_mm2);    % Particle max area [mm^2]
    particle(id_p).mean_area_mm2 = mean(particle(id_p).all_area_mm2);      % Mean of the raw areas [mm^2]
    particle(id_p).mean_area_m2 = particle(id_p).mean_area_mm2*1e-6;       % Mean of the raw areas [m^2]
    particle(id_p).all_x_mm = table_raw(:,6);                              % All particle raw X coordinate [mm]
    particle(id_p).all_y_mm = table_raw(:,7);                              % All particle raw Y coordinate [mm] 
    particle(id_p).all_x_m = table_raw(:,6)*1e-3;                          % All particle X coordinate [m] 
    particle(id_p).all_y_m = table_raw(:,7)*1e-3;                          % All particle Y coordinate [m]
    particle(id_p).all_t_s = data.dt_s*[1:1:length(particle(id_p).all_x_mm)]; % All times [s]
    particle(id_p).x4tv_m = particle(id_p).all_x_m(1:last_frame_tv);       % X coordinates to be used for terminal velocity [m]
    particle(id_p).y4tv_m = particle(id_p).all_y_m(1:last_frame_tv);       % Y coordinates to be used for terminal velocity [m]
    particle(id_p).x4charge_m = particle(id_p).all_x_m(last_frame_tv+1:end); % X coordinates to be used for charge estimation [m]
    particle(id_p).y4charge_m = particle(id_p).all_y_m(last_frame_tv+1:end); % Y coordinates to be used for charge estimation [m]
    particle(id_p).t4tv_s = particle(id_p).all_t_s(1:last_frame_tv);       % Times in the terminal velocity part [s]
    particle(id_p).t4charge_s = particle(id_p).all_t_s(last_frame_tv+1:end); % Times in the charge measurement [s]
    particle(id_p).filename = filename;
    
    
end

function A = readSingleTxt(filename)

    fileID = fopen(filename,'r');
    formatSpec = '%i  %f  %f  %i  %f  %f  %f  %f  %f  %f  %f  %i  %i  %i  %f  %f';
    sizeA = [16 Inf];
    A = fscanf(fileID,formatSpec,sizeA);
    A = A';
    fclose(fileID);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% CREATION OF THE MONTE CARLO DATASETs  %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Creation of the dataset for the areas for a single particle

function [MC_distributions, control] = MCDatasetArea(single_particle, data, MC_distributions)

%     hist_fit_type = 'Normal';
    hist_fit_type = 'Loglogistic';
    
    % Hist fit type for areas   

    subplot(2,1,1)
    histogram(single_particle.all_area_mm2,10,'Normalization','probability')
    subplot(2,1,2)
    histogram(single_particle.all_area_mm2,10,'Normalization','pdf')
        
    
    % Fitting of the raw areas expressed in mm^2 with a PDF
    pdf_fit = fitdist(single_particle.all_area_mm2, hist_fit_type);              % mu = pd.mu; sigma = pd.sigma;
    
    % Creation of the Monte Carlo PDF (unlimited) 
    pd = makedist(hist_fit_type,'mu',pdf_fit.mu,'sigma',pdf_fit.sigma);
    MC_distributions.area_mm2.mu = pdf_fit.mu;
    MC_distributions.area_mm2.sigma = pdf_fit.sigma;
    MC_distributions.area_mm2.fit_type = hist_fit_type;
    
    % Creation of the Monte Carlo PDF (truncated)
    pd_truncated = truncate(pd, single_particle.min_all_area_mm2, single_particle.max_all_area_mm2); 
    
    % Creation of the Monte Carlo dataset
    MC_distributions.area_mm2.dataset = random(pd_truncated, data.N_Montecarlo, 1);
    
                %%% Comparison of the raw PDF and the new PDF %%%
    
    % Transformation of the Monte Carlo dataset into a PDF
    [conteggi_new, indici_new] = hist(MC_distributions.area_mm2.dataset, data.N_hist_1); 
    pdf_new = conteggi_new./data.N_Montecarlo;
    
    % PDF of the raw areas
    N_areas = length(single_particle.all_area_mm2);
    [conteggi_raw, indici_raw] = hist(single_particle.all_area_mm2, data.N_hist_1); 
    pdf_raw = conteggi_raw./N_areas;
    
    % Creation of a control_structure
    control.pdf_new = pdf_new;
    control.indici_new = indici_new;
    control.pdf_raw = pdf_raw;
    control.indici_raw = indici_raw;
    
    subplot(2,1,1)
    bar(control.indici_raw, control.pdf_raw);
    ylim([0 max([control.pdf_new control.pdf_raw])])
    subplot(2,1,2)
    bar(control.indici_new, control.pdf_new);
    ylim([0 max([control.pdf_new control.pdf_raw])])
%     input('sdsd')

end

% Creation of the dataset for the densities for a single particle

function [MC_distributions] = MCDatasetDensity(data, MC_rho_param, MC_distributions)
    
    pd = makedist(MC_rho_param.hist_fit_type_rho,'mu',MC_rho_param.mu,'sigma',MC_rho_param.sigma);
    pd_truncated = truncate(pd, data.rho_min, data.rho_max); 
    MC_distributions.rho.dataset = random(pd_truncated, data.N_Montecarlo, 1); % [kg/m^3]
    MC_distributions.rho.mu = MC_rho_param.mu;
    MC_distribution.rho.sigma = MC_rho_param.sigma;
    MC_distribution.rho.fit_type = MC_rho_param.hist_fit_type_rho;
    
%     % Plot for densities
%     hold on
%     errorbar(single_particle.moda_d_m*1e6 , single_particle.density_mode, ...
%              single_particle.density_mode-single_particle.density_5, ...
%              single_particle.density_95-single_particle.density_mode, '.', 'MarkerSize', 20);
%     hold off
    
end

% Creation of the dataset for the electric field

function [MC_distributions] = MCDatasetElectricField(data, MC_distributions)

    hist_fit_type = 'Normal';
    MC_distributions.E_field.mu = data.E0;
    MC_distributions.E_field.sigma = data.E0_sigma;
    MC_distributions.E_field.fit_type = hist_fit_type;
    pd = makedist(hist_fit_type,'mu',data.E0,'sigma',data.E0_sigma);
    pd_truncated = truncate(pd,0,1e20);
    MC_distributions.E_field.dataset = random(pd_truncated, data.N_Montecarlo, 1);% Gaussian distribution for the electric field
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% SETTLING VELOCITY COMPUTATION %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [single_particle, data] = computeTV(single_particle, data)

    % Linear fit of the vertical trajectory
    [single_particle, data] = yFitting4TV(single_particle, data);
    p1 = single_particle.y_Fit_4TV.p1;
    p2 = single_particle.y_Fit_4TV.p2;
    single_particle.time_vec = linspace(min(single_particle.t4tv_s), max(single_particle.t4tv_s), data.N_points_fit);
    single_particle.y_fit = p1 * single_particle.time_vec + p2;
    single_particle.TV = abs(p1);
    single_particle.TV_err_abs = computeErrorLinear(single_particle.y_Fit_4TV_conf);
    single_particle.TV_rel_err = abs(single_particle.TV_err_abs./single_particle.TV);

end

function [single_particle, data] = yFitting4TV(single_particle, data)

    % Linear fit of the vertical trajectory of the falling particle before
    % entering in the electric field zone
    
    [fitobject, gof] = fitCurve(single_particle.t4tv_s', single_particle.y4tv_m, 'poly1');
    single_particle.y_Fit_4TV.p1 = fitobject.p1;
    single_particle.y_Fit_4TV.p2 = fitobject.p2;
    single_particle.y_Fit_4TV_conf = confint(fitobject);
    single_particle.y_Fit_4TV_R2 = gof.rsquare; 
    
end   

% Computation of the error on the parameter p1 for a linear case [scalar] 
function [err_final] = computeErrorLinear(matrix_ci)

    err_p1 = 0.5*(matrix_ci(2,1)-matrix_ci(1,1));
    err_final = err_p1;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% PARTICLE DENSITY COMPUTATION %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% The following function computes the density distribution starting from
% the areas and the terminal velocity. It is also used to determine the
% parameters for the Monte Carlo dataset
function [single_particle, data, MC_rho_param] = computeDensity(single_particle, data, MC_distributions)

    % Defining parameters for the Monte Carlo over the density values
    hist_fit_type_rho = 'Lognormal';                                       % Fit type for the density distribution                                       
    N_MC_density = 1000000;                                                % Number of Monte Carlo repetitions for the density

    %%%%%%%%%  Monte Carlo distribution for the terminal velocity %%%%%%%%%

    % Terminal velocity
    v_t = single_particle.TV;                                              % [m/s]
    
    % Uncertainty on terminal velocity
    vt_err = single_particle.TV_err_abs;                                   % [m/s]
    
    % Gaussian distribution for velocities
    pd = makedist('Normal','mu',v_t,'sigma',vt_err);
%     t = truncate(pd,0.0001,50);
    v_MC = random(pd, N_MC_density, 1);                                     % Gaussian distribution for velocities (in m/s)
    
    %%%%%%%%%  Monte Carlo distribution for the diameters %%%%%%%%%
    % We repeat what done in MCDatasetArea but with a different number of
    % N. In fact, the Monte Carlo evaluation of the density is controlled
    % by the internal number N_MC_density. This is done to allow the
    % density to have a larger number of points.
    
    pd = makedist(MC_distributions.area_mm2.fit_type,'mu',MC_distributions.area_mm2.mu,'sigma',MC_distributions.area_mm2.sigma);
    pd_truncated = truncate(pd, single_particle.min_all_area_mm2, single_particle.max_all_area_mm2); 
    areas_MC = random(pd_truncated, N_MC_density, 1);                      % [mm^2]
    d_mm_MC = (4*areas_MC/pi).^(0.5);                                      % Diameters in mm [mm]
    d_m_MC = d_mm_MC*1e-3;                                                 % Diameters in meters [m]
    [conteggi, indici] = hist(d_mm_MC, 100);                    
    [inutile, ind_moda] = max(conteggi);
    moda_d_mm = indici(ind_moda);                                          % Mode of the diameter [mm]
    
    
    %%%%%%%%%%%%%%%%%%%%% Actual density calculation %%%%%%%%%%%%%%%%%%%%%%
    
    % Drag coefficient for N_MC_density particles
    Cd_MC = calculateCD(d_m_MC, v_MC, data);
    
    % Aggregate density distribution
    rho_MC = (6/8 .* Cd_MC .* data.rho_air .* v_MC.^2 ./ (d_m_MC.*data.g) + data.rho_air);
    rho_MC_clean = rho_MC(rho_MC<5000 & rho_MC>0);
        
    
    %%%%%% Derivation of the MC parameters for the charge inversion %%%%%%%  
    
    % ATTENTION: here we derive the parameters of the distribution by means
    % of "fitdist". This information will be used later on in the code.
    pdf_fit = fitdist(rho_MC_clean, hist_fit_type_rho);                   % mu = pd.mu; sigma = pd.sigma;
    MC_rho_param.mu = pdf_fit.mu;
    MC_rho_param.sigma = pdf_fit.sigma;
    MC_rho_param.hist_fit_type_rho = hist_fit_type_rho;
    
%     % Comparison of the raw PDF and the theoretical PDF (commented) %
%     histfit(rho_MC_clean,100,hist_fit_type_rho)
    
    %%%%%%%%%%%%%%%%%%%%%%%%% Output values for plot %%%%%%%%%%%%%%%%%%%%%%
    
    % Calculation of the mode of the distribution
    [conteggi, indici] = hist(rho_MC_clean, 100);                          % Counts per bin for the histogram truncated              
    [inutile, ind_moda] = max(conteggi);
    moda_density = indici(ind_moda);                                       % Mode of the density (kg/m^3)
    
    % Determination of the percentiles for plot
    out = prctile(rho_MC_clean,[5 16 50 84 95]);
    percentile_5 = out(1);
    percentile_16 = out(2);
    percentile_50= out(3);
    percentile_84 = out(4);
    percentile_95 = out(5);
    
    % Proper outputs of the function
    single_particle.density_all = rho_MC_clean;
    single_particle.density_mode = moda_density;
    single_particle.density_5 = percentile_5;
    single_particle.density_95 = percentile_95;
    single_particle.moda_d_m = moda_d_mm*1e-3;                             % Particle mode diameter [m]
    
end

function Cd_monte = calculateCD(d_monte, v_monte, closet)

    fl = 1;
    el = 1;
    
    Fs = fl .* (el.^1.3);                                                  % Shape descriptor - Stoke's regime
    Fn = (fl.^2) .* el;                                                    % Shape descriptor - Newton regime
    Ks = 0.5 .* (Fs.^(1/3) + Fs.^(-1/3));                                  % Stoke's drag correction
    Kn = (10.^(.45 * (-log10(Fn)).^0.99));                                 % Newton's drag correction 
    
    Reynolds_monte = (abs(v_monte).*d_monte./closet.mu_kyn_air);
    Re_S = Reynolds_monte .* Kn ./ Ks; 

    % Ganser Re
    Cd_monte = (Kn .* (24.*(1 + .125.*Re_S.^(2/3))./Re_S + .46./(1+5330./Re_S)));     % Drag coef
    

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% MONTE CARLO INVERSION %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Function to evaluate the single charge probability distribution: this
% loop is over a single particle

function [montecarlo_output] = montecarloInversion(data, single_particle, MC_distributions)

    % Original stochastic dataset for Monte Carlo
    all_A_mm2 = MC_distributions.area_mm2.dataset;                         % Areas dataset for a single particle [mm^2]
    all_Rhos = MC_distributions.rho.dataset;                               % Densities dataset [kg/m^3]
    all_E = MC_distributions.E_field.dataset;                              % Electric field dataset [kV/m]
    
    % Derived variables from the stochastic dataset
    all_A_m2 = all_A_mm2*1e-6;                                             % Areas dataset in m^2 [m^2]
    all_D_m = sqrt(4*all_A_m2/pi);                                         % Diameters dataset [m]
    all_M_kg = pi/6*all_D_m.^3.*all_Rhos;                                  % All masses [kg]
    Q_min = -data.MaxQDensity * max(all_A_m2);                             % Minimum charge expected for a single aggregate [C]
    Q_max = +data.MaxQDensity * max(all_A_m2);                             % Maximum charge expected for a single aggregate [C]
    
    % Initial conditions extracted from the trajectory for a single particle
    t_vec = single_particle.t4charge_s;                                    % All times extracted from the HSC
    x_0 = single_particle.x4charge_m(1);                                   % Initial condition over x at the entrance of the HVCP
    v_x_0 = computeInitialXVelocity4Charge(single_particle);               % Initial condition for the x velocity at the entrance of the HVCP  
    y_0 = single_particle.y4charge_m(1);                                   % Initial condition over y at the entrance of the HVCP
    v_y_0 = -single_particle.TV(1);                                         % Initial condition over the y velocity at the entranche of the HVCP

    
    montecarlo_output.Q = zeros(data.N_Montecarlo,1);
    
    % Loop over N_Montecarlo values for the electric field, the area of the
    % particle, the density
    for i = 1:data.N_Montecarlo
        
        i
        
        % Fixed values within the loop
        E_fixed = all_E(i);                                                % Single value of the electric field
        A_fixed_m2 = all_A_m2(i);                                          % Single value of the area [m^2]
        D_fixed_m = all_D_m(i);                                            % Single value of the diameter [m]
        M_fixed_kg = all_M_kg(i);                                          % Single value of the mass [kg]
        
        % Inversion procedure (parallel loop inside)
        [output] = inversion4NCharges(data, single_particle, t_vec, x_0, v_x_0, y_0, v_y_0, ...
                                      A_fixed_m2, E_fixed, M_fixed_kg, D_fixed_m, Q_min, Q_max, 1);
                                      
        montecarlo_output.Q(i) = output.best.Q;                              
        
    end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%  ELECTRICAL CHARGE DETERMINATION %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Main code for the inversion using just the modes of the distributions
% (i.e. no Monte Carlo inversion here)

function [output] = inversionUsingModes(data, MC_distributions, single_particle)

    % Reading the three modes (independent variables)
    mode_Area_mm2 = single_particle.mean_area_mm2;                         % [mm2] 
    E_single = data.E0;                                                    % [V/m]                         
    rho_single = findMode(MC_distributions.rho.dataset);                   % [kg/m^3]
    
    % Deriving dependent variables
    A_single_m2 = mode_Area_mm2 * 1e-6;                                    % From mm2 to m2 [m2]
    D_single_m = sqrt(4*A_single_m2/pi);                                   % Single diameter under the assumption of a circle [m]
    M_single_kg = pi/6*D_single_m^3*rho_single;                            % Single mass under the assumption of a sphere [kg]
    
    Q_min = -data.MaxQDensity * A_single_m2;                               % Minimum charge expected for a single aggregate [C]
    Q_max = +data.MaxQDensity * A_single_m2;                               % Maximum charge expected for a single aggregate [C]
    
%     Data extracted from the trajectory
    t_vec = single_particle.t4charge_s;                                    % All times extracted from the HSC
    x_0 = single_particle.x4charge_m(1);                                   % Initial condition over x at the entrance of the HVCP
    v_x_0 = computeInitialXVelocity4Charge(single_particle);               % Initial condition for the x velocity at the entrance of the HVCP  
    y_0 = single_particle.y4charge_m(1);                                   % Initial condition over y at the entrance of the HVCP
    v_y_0 = -single_particle.TV(1);                                         % Initial condition over the y velocity at the entranche of the HVCP

%     velocityAlongX(single_particle);
    output = inversion4NCharges(data, single_particle, t_vec, x_0, v_x_0, y_0, v_y_0, ...
                                     A_single_m2, E_single, M_single_kg, D_single_m, Q_min, Q_max, 0);
                        
end

function [output] = inversion4NCharges(data, single_particle, t_vec, x_0, v_x_0, y_0, v_y_0, ...
                                           A_single, E_single, M_single, D_single, Q_min, Q_max, flag)
                             
    if (flag == 0)
        N_Qs = data.N_Qsingle;
        % Regular spacing between charges
        Q0s = linspace(Q_min, Q_max, N_Qs);                           % Vector of charges [C]
    else
        % Uniform distribution for the unknown electric charges
        N_Qs = data.N_Qs;
        Q0s = Q_min + (Q_max-Q_min).*rand(N_Qs,1);                         % Vector of charges [C]
        
    end
           
    diff = zeros(data.N_Qs,1);                                             % Initialization of the array of differences
    % Parallel loop
    parfor j=1:N_Qs
    
        Q_single = Q0s(j);
            
        [T, x_theo, v_p_x, y_theo, v_p_y] = singleChargeODE(data, t_vec, x_0, v_x_0, y_0, v_y_0, ...
                                                            A_single, E_single, Q_single, M_single, D_single);
        
        if length(x_theo) == length(single_particle.x4charge_m)
            diff(j) = calculateDifferenceAlongX(single_particle.x4charge_m, x_theo);
            
            temp(j).x_theo = x_theo;
            temp(j).y_theo = y_theo;
            temp(j).T = T;
            
        else
            diff(j) = NaN;
            
            temp(j).x_theo = 0;
            temp(j).y_theo = 0;
            temp(j).T = 0;
            
        end
        
%         single_inversion(j).Q = Q_fixed;
        
    end

    % Only consider not NaN elements
    diff_not_NaN = diff(~isnan(diff));
        
    % Find the best j-th charge to the observed trajectory
    if isempty(diff_not_NaN)<1
        [~, id_min] = min(diff);
    else
        id_min = 1;
    end
   
    output.best.all_x = temp(id_min).x_theo;
    output.best.all_y = temp(id_min).y_theo;
    output.best.all_T = temp(id_min).T;
    output.best.Q = Q0s(id_min);
%     Q0s(id_min)
    
%     figure(12121)
%     hold on
%     plot(output.best.all_x, output.best.all_y, 'or');
%     plot(single_particle.x4charge_m, single_particle.y4charge_m, '+b');
%     axis equal
%     
%     figure(23)  
%     subplot(2,1,1)
%     hold on
%     plot(output.best.all_T, output.best.all_x, 'or');
%     plot(single_particle.t4charge_s, single_particle.x4charge_m, '+b');
%     hold off
%     
%     subplot(2,1,2)
%     hold on
%     plot(output.best.all_T, output.best.all_y, 'or');
%     plot(single_particle.t4charge_s, single_particle.y4charge_m, '+b');
%     hold off
%     input('Pisc')
%     close all;
end

% Function for the computation of the single charge for fixed values of the
% independent variables
    
function [T, x, v_p_x, y, v_p_y] = singleChargeODE(data, t_vec, x_0, v_x_0, y_0, v_y_0, ...
                                                   p_area_m2, E_single, Q_single, M_single, D_single)
                         
    Tspan = t_vec;  
    IC = [x_0 v_x_0 y_0 v_y_0];                                            % Initial conditions for the single simulation
    options = odeset('RelTol',1e-5,'AbsTol',1e-5);                         % Tolerances of the ODE solver
    [T, XV] = ode45(@(t,Y) odeEq(t, Y, data, p_area_m2, E_single, Q_single, M_single, D_single), Tspan, IC, options);
    x = XV(:,1);
    v_p_x = XV(:,2);
    y = XV(:,3);
    v_p_y = XV(:,4);
    
end

% Actual ODEs thatare solved by the code

function dY_dt = odeEq(t, Y, data, A_single, E_single, Q_single, M_single, D_single)
    
    x = Y(1);
    v_x = Y(2);
    y = Y(3);
    v_y = Y(4);
      
    Re_p = data.rho_air * D_single .* v_x / data.vis_dyn;
    Re_p = abs(Re_p);
    
    C_d = dragCliftGauvin(Re_p);
    F_d = 0.5 * data.rho_air * C_d * A_single * v_x^2;
    F_e = Q_single * E_single;
   
    d_x_p_dt = v_x;                                                        % dx/dt = vx
    d_v_p_x_dt = (F_d+F_e)/M_single;                                       % dvx/dt = Fx/m
    
    d_y_p_dt = v_y;   
    d_v_p_y_dt = 0;
                               
    dY_dt(1) = d_x_p_dt;
    dY_dt(2) = d_v_p_x_dt;
    dY_dt(3) = d_y_p_dt;
    dY_dt(4) = d_v_p_y_dt;
                                            
    dY_dt = dY_dt';                  
    
end

% Drag coefficient for a sphere

function C_d = dragCliftGauvin(Re_p)

    C_d = 24/Re_p * (1+0.15*Re_p^(0.687)) + ...
        0.42/(1+(42500/Re_p^1.16));

end

% Initial conditions on the velocity at the entrance of the HVCP

function [v_x_0] = computeInitialXVelocity4Charge(single_particle)
    
    [fitobject, gof] = fitCurve(single_particle.t4charge_s', single_particle.x4charge_m, 'poly5');
    v_x_0 = (5 * fitobject.p1 * single_particle.t4charge_s(1)^4 + ...
             4 * fitobject.p2 * single_particle.t4charge_s(1).^3 + ...
             3 * fitobject.p3 * single_particle.t4charge_s(1).^2 + ...
             2 * fitobject.p4 * single_particle.t4charge_s(1).^1 + ...
             1 * fitobject.p5);                                            % Single velocity in m/s
    
%     close all
%     figure(888888)
%     subplot(2,1,1)
%     hold on
%     plot(single_particle.t4charge_s, single_particle.x4charge_m, 'o');
%     plot(single_particle.t4charge_s, ...
%          fitobject.p1 * single_particle.t4charge_s.^5 + ...
%          fitobject.p2 * single_particle.t4charge_s.^4 + ...
%          fitobject.p3 * single_particle.t4charge_s.^3 + ...
%          fitobject.p4 * single_particle.t4charge_s.^2 + ...
%          fitobject.p5 * single_particle.t4charge_s.^1 + ...
%          fitobject.p6, '-');
%     subplot(2,1,2)
%     plot(single_particle.t4charge_s, ...
%          5 * fitobject.p1 * single_particle.t4charge_s.^4 + ...
%          4 * fitobject.p2 * single_particle.t4charge_s.^3 + ...
%          3 * fitobject.p3 * single_particle.t4charge_s.^2 + ...
%          2 * fitobject.p4 * single_particle.t4charge_s.^1 + ...
%          1 * fitobject.p5, '-');
%     
%     hold off
%     input('sdsdsd')
end

function [v_x] = velocityAlongX(single_particle)

    [fitobject, gof] = fitCurve(single_particle.t4charge_s', single_particle.x4charge_m, 'poly2');
    v_x = (2*fitobject.p1 * single_particle.t4charge_s + fitobject.p2);      % Single velocity in m/s
    
%     close all
%     figure(888888)
%     subplot(2,1,1)
%     % Trajectory
%     hold on
%     plot(single_particle.t4charge_s, single_particle.x4charge_m, 'o');
%     plot(single_particle.t4charge_s, fitobject.p1 * single_particle.t4charge_s.^2 + fitobject.p2 * single_particle.t4charge_s + fitobject.p3, '-');
%     
%     subplot(2,1,2)
%     % Velocity
%     plot(single_particle.t4charge_s, ...
%          2 * fitobject.p1 * single_particle.t4charge_s + fitobject.p2, '-');
%     
%     hold off
%     input('sdsdsd')
end

function [err_final] = computeErrorParabola(matrix_ci, time_vector)

    err_p1 = 0.5*(matrix_ci(2,1)-matrix_ci(1,1));
    err_p2 = 0.5*(matrix_ci(2,2)-matrix_ci(1,2));
    err_p3 = 0.5*(matrix_ci(2,3)-matrix_ci(1,3));
    
    err_final = mean(sqrt( (2*time_vector).^2 .* err_p1.^2 + (err_p2).^2));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TOOL FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% MATLAB fitting subroutine

function [fitobject, gof] = fitCurve(x, y, fitType)

    [fitobject,gof] = fit(x,y,fitType);

end

function diff = calculateDifferenceAlongX(x_measured, x_theoretical)

    diff = sqrt((x_measured-x_theoretical).^2);
    diff = sum(diff);

end

function moda_final = findMode(data)

    [conteggi, indici] = hist(data, 100);                    
    [inutile, ind_moda] = max(conteggi);
    moda_final = indici(ind_moda);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% MONTECARLO SIMULATION %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function particle = masterFunction(data)

%     figure(1)
    particle = [];
    MC_distributions = [];
    
    % Loop over each single file (i.e. particle)
    
    for i=1:length(data.fileIdVector)
        
%         i
       
        % Single particle object: reading the measured quantities from HSC,
        % building the final structure "particle" in which we store all the
        % info and results related to all single particles
        id_p = data.fileIdVector(i);                                       % Sample "id" as reported in the folder 
        particle = createNewParticle(id_p, data, particle);                
        id_p
        
        % Single particle "alias" (...easier to use) which is overwritten at
        % each iteration
        single_particle = particle(id_p);                                  % alias for i-th particle                                 
        
        % Terminal velocity computation
        [single_particle, data] = computeTV(single_particle, data);
        
        % Filling the info for the final structure "particle"
        particle(id_p).TV = single_particle.TV;
        particle(id_p).TV_err_abs = single_particle.TV_err_abs;
        particle(id_p).TV_err_rel = abs(single_particle.TV_err_abs/single_particle.TV);
        
        % Monte Carlo dataset for areas, relatively to the single particle
        [MC_distributions, control] = MCDatasetArea(single_particle, data, MC_distributions);
        
        % Computation of the density of the single particle
        [single_particle, data, MC_rho_param] = computeDensity(single_particle, data, MC_distributions);

        % Monte Carlo dataset for the density, relatively to the single particle
        [MC_distributions] = MCDatasetDensity(data, MC_rho_param, MC_distributions);
        
        % Monte Carlo dataset for the electric field, relatively to the single particle
        [MC_distributions] = MCDatasetElectricField(data, MC_distributions);
        
% %         % Calculation of the charge using only the mode of the
% %         % distributions (for debugging and double checking)
%         disp('Inversion using modes')
%         [output] = inversionUsingModes(data, MC_distributions, single_particle);
%         particle(id_p).bestQSinMode = output.best.Q;
%        
%         % Monte Carlo inversion
%         disp('Inversion using Monte Carlo')
%         [montecarlo_output] = montecarloInversion(data, single_particle, MC_distributions);
%         
%         particle(id_p).MC_Q_dataset = montecarlo_output.Q;
%         particle(id_p).MC_A_mm2_dataset = MC_distributions.area_mm2.dataset;
%         particle(id_p).MC_rho_dataset = MC_distributions.rho.dataset;
%         particle(id_p).MC_E_dataset = MC_distributions.E_field.dataset;
%         
%         
        
        
        % Plot trajectory for the computation of terminal velocities
%         hold on
%         plot(single_particle.t4tv_s , single_particle.y4tv_m, 'o');
%         plot(single_particle.time_vec, single_particle.y_fit, '-');
%         hold off
        
%         hold on
%         plot(id_p , single_particle.y_Fit_4TV_R2, 'o', 'MarkerSize', 20);
%         hold off
        
       
%         pd_ci = paramci(pd)
%         methods(pd)
        
%         histfit(particle(id_p).all_area_mm2,data.N_hist_1,'lognormal');
        
%         hist(particle(id_p).all_area_mm2, data.N_hist_1);
        
        input('sdsddsd')
        close all
    end

end

